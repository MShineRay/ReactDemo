({
  title: function () {
    return "Bear > Shark";
  },
  entities: "&quot; \"'<>`=/"
})
